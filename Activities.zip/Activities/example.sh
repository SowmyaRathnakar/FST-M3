echo "Hello World!"
echo "Hello" > ./file1.txt


